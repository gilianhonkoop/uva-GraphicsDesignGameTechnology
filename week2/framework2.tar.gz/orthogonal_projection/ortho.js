/*
 * Student names:
 * Student numbers:
 *
 */

function myOrtho(left, right, bottom, top, near, far) {

    var mat = [
        1.0 ,0.0, 0.0, 0.0,
        0.0, 1.0, 0.0, 0.0,
        0.0, 0.0, 1.0, 0.0,
        0.0, 0.0, 0.0, 1.0
    ];

    return mat;
}
